#ifndef __BSP_DELAY_H
#define __BSP_DELAY_H

#define u32 unsigned int 
#define u8 unsigned char 
	
void delay_ms(u8 ms);

#endif 
