#ifndef __BSP_KEY_H
#define __BSP_KEY_H

void key_scan();        //相当于函数的声明


#endif /*__BSP_KEY_H*/
