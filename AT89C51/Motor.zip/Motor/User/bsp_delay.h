#ifndef __BSP_DELAY_H
#define __BSP_DELAY_H

#include <reg52.h>

void delay(u8 ms);     //相当于函数的声明

#endif /*__BSP_DELAY_H*/
