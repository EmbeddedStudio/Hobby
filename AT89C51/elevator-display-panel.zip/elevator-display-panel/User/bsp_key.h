#ifndef __BSP_KEYPAD_H
#define __BSP_KEYPAD_H

#include "main.h"

u8 key_scan(void);
void key_control(u8 key_value);

#endif /* __BSP_KEYPAD_H */
