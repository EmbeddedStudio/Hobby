#ifndef __MAIN_H
#define __MAIN_H

#include "reg51.h"

/* 类型重定义 */
#define u8  unsigned char
#define u16 unsigned short
#define u32 unsigned long

#endif /* __MAIN_H */